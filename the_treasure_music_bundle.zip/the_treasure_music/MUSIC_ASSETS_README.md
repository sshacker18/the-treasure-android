# THE TREASURE — soundtrack assets

Prepared from audio files supplied in the project conversation. WAV files were encoded to OGG Vorbis at quality 5 for smaller offline game packaging.

## Assets
- `assets/fairy_adventure.ogg` — supplied as `fairy_adventure_bpm140_0.ogg`
- `assets/pirate_adventure.ogg` — encoded from supplied `pirate_adventure.wav`
- `assets/epic_endgame_cinematic.ogg` — encoded from supplied `ChoirChordsBassMaster (1).wav`

## Suggested use
- Fairy Adventure: exploration ambience
- Pirate Adventure: adventure/action sequence
- Epic Endgame Cinematic: climax or treasure reveal

## Licensing release gate
Before publishing, verify and archive the original asset-page license for each track and any applicable attribution. Do not treat this README as proof of license ownership. Add the exact source URLs and license text here after verification.
